you can run the code with:
	python3 main.py
needs to have stopwords.txt in the same directory.
you can change the stop_enable variable on the 6th line between 0 and 1 to disable or enable stopwords.